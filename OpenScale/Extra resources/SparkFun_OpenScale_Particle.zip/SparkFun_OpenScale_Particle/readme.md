SparkFun Beehive Particle Sketch
===========

This is the sketch that is used on the Particle Core.